import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import {
  ArrowRight,
  ArrowDownRight,
  ArrowUpRight,
  Camera,
  Check,
  ChevronLeft,
  ChevronRight,
  Code2,
  Copy,
  Layers3,
  Mail,
  Menu,
  Play,
  ShieldCheck,
  Sparkles,
  Workflow,
  X,
} from 'lucide-react';

type GalleryItem = readonly [string, string, string, string];

const email = 'preethamjee2008@gmail.com';

const skills = [
  'Python', 'Python Automation', 'AI & Applications', 'Cyber Security', 'React', 'TypeScript',
  'HTML', 'CSS', 'JavaScript', 'SQL', 'Web Development', 'Responsive Web Design', 'UI / UX',
  'API Development', 'API Integration', 'API Automation', 'Payment Gateways', 'Telegram Bot Development',
  'Workflow Automation', 'Digital Marketing', 'SEO Optimisation', 'Social Media Marketing',
  'Instagram Growth', 'YouTube Growth', 'Content Strategy', 'Audience Growth',
];

const youtube: GalleryItem[] = [
  ['/assets/proof/accounts-01.jpg', 'PREETHAM', '12.4M subscribers', 'Primary channel snapshot'],
  ['/assets/proof/accounts-02.jpg', 'PREETHAM CREATES', '12.8M subscribers', 'Creator channel snapshot'],
];

const payments: GalleryItem[] = [
  ['/assets/proof/payment-01.jpg', 'AUG 2024', '₹5,000', 'Channel transaction snapshot'],
  ['/assets/proof/payment-02.jpg', 'NOV 2024', '₹5,000', 'Channel transaction snapshot'],
  ['/assets/proof/payment-03.jpg', 'OCT 2024', '₹5,000', 'Channel transaction snapshot'],
  ['/assets/proof/payment-04.jpg', 'SEP 2025', '₹5,000', 'Channel transaction snapshot'],
];

const analytics: GalleryItem[] = [
  ['/assets/proof/instagram-overview.png', 'REACH', '75.67M', 'Views shown · 90 days'],
  ['/assets/proof/instagram-audience.png', 'AUDIENCE', '21,957', 'Followers shown · 30 days'],
  ['/assets/proof/instagram-grid.jpg', 'CONTENT', '5.9M → 1.9M', 'Top visible reel views'],
  ['/assets/proof/instagram-reach.jpg', 'DEPTH', '59L → 16L', 'Additional visible view snapshots'],
];

const projects = [
  ['/assets/proof/accounts-01.jpg', 'Audience systems', 'Channel growth'],
  ['/assets/proof/instagram-overview.png', 'Social analytics', 'Digital marketing'],
  ['/assets/world/portfolio-film-poster.png', 'Portfolio film', 'Web development'],
  ['/assets/proof/payment-01.jpg', 'Payment archive', 'Proof of work'],
] as const;

function Reveal({ children, className = '', delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return <div className={`reveal ${className}`} style={{ '--delay': `${delay}ms` } as CSSProperties}>{children}</div>;
}

function SectionLabel({ index, children }: { index: string; children: ReactNode }) {
  return <p className="section-label mono"><span>{index}</span><span>{children}</span></p>;
}

function NumberTicker({ value, suffix = '' }: { value: number; suffix?: string }) {
  const [current, setCurrent] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting || started.current) return;
      started.current = true;
      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (reduced) {
        setCurrent(value);
        return;
      }
      const startedAt = performance.now();
      const duration = 1150;
      const frame = (now: number) => {
        const progress = Math.min((now - startedAt) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        setCurrent(Math.round(value * eased));
        if (progress < 1) requestAnimationFrame(frame);
      };
      requestAnimationFrame(frame);
    }, { threshold: 0.4 });
    observer.observe(node);
    return () => observer.disconnect();
  }, [value]);

  return <span ref={ref}>{current}{suffix}</span>;
}

function Gallery({ items, tone = 'neutral' }: { items: GalleryItem[]; tone?: string }) {
  const [active, setActive] = useState(0);
  const item = items[active];
  const previous = () => setActive((current) => (current - 1 + items.length) % items.length);
  const next = () => setActive((current) => (current + 1) % items.length);

  return (
    <div className={`gallery gallery--${tone}`}>
      <div className="gallery-stage">
        <button className="gallery-arrow left" aria-label="Previous gallery image" data-testid={`button-gallery-previous-${tone}`} onClick={previous}>
          <ChevronLeft size={19} />
        </button>
        <img key={item[0]} className="gallery-image" src={item[0]} alt={item[1]} data-testid={`img-gallery-${tone}`} />
        <button className="gallery-arrow right" aria-label="Next gallery image" data-testid={`button-gallery-next-${tone}`} onClick={next}>
          <ChevronRight size={19} />
        </button>
        <span className="gallery-index" data-testid={`text-gallery-index-${tone}`}>{String(active + 1).padStart(2, '0')} / {String(items.length).padStart(2, '0')}</span>
      </div>
      <div className="gallery-meta">
        <div>
          <span>{item[1]}</span>
          <strong>{item[2]}</strong>
          <small>{item[3]}</small>
        </div>
        <div className="gallery-dots" aria-label="Choose gallery image">
          {items.map((entry, index) => (
            <button
              key={entry[0]}
              className={index === active ? 'active' : ''}
              aria-label={`Open image ${index + 1}`}
              aria-pressed={index === active}
              data-testid={`button-gallery-dot-${tone}-${index + 1}`}
              onClick={() => setActive(index)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function Header({ menuOpen, setMenuOpen }: { menuOpen: boolean; setMenuOpen: (open: boolean) => void }) {
  const close = () => setMenuOpen(false);
  return (
    <header className="site-nav">
      <a className="brand" href="#top" data-testid="link-brand" onClick={close}>P<span>.</span></a>
      <nav className={menuOpen ? 'open' : ''} aria-label="Primary navigation">
        <a href="#story" data-testid="link-story" onClick={close}>Story</a>
        <a href="#proof" data-testid="link-proof" onClick={close}>Proof</a>
        <a href="#analytics" data-testid="link-analytics" onClick={close}>Analytics</a>
        <a href="#builds" data-testid="link-builds" onClick={close}>Build lanes</a>
        <a className="nav-pill" href="#contact" data-testid="link-contact" onClick={close}>Let's talk <ArrowUpRight size={13} /></a>
      </nav>
      <button
        className="nav-toggle"
        aria-label={menuOpen ? 'Close navigation' : 'Open navigation'}
        aria-expanded={menuOpen}
        data-testid="button-menu"
        onClick={() => setMenuOpen(!menuOpen)}
      >
        {menuOpen ? <X size={19} /> : <Menu size={19} />}
      </button>
    </header>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [viewer, setViewer] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [openService, setOpenService] = useState(0);
  const shellRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const revealItems = document.querySelectorAll('.reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setViewer(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    const node = shellRef.current;
    if (!node) return;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const move = (event: PointerEvent) => {
      if (reduced) return;
      node.style.setProperty('--mx', `${event.clientX}px`);
      node.style.setProperty('--my', `${event.clientY}px`);
    };
    window.addEventListener('pointermove', move, { passive: true });
    return () => window.removeEventListener('pointermove', move);
  }, []);

  const copyEmail = async () => {
    try {
      await navigator.clipboard?.writeText(email);
    } finally {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    }
  };

  const services = useMemo(() => [
    ['01', 'Digital products', 'Interfaces, websites and experiments that feel polished, fast and alive.', <Code2 size={21} />],
    ['02', 'Automation flows', 'Turning repetitive workflows into simple systems that save time.', <Workflow size={21} />],
    ['03', 'Growth experiments', 'Learning how content, community and product storytelling create reach.', <Sparkles size={21} />],
  ] as const, []);

  return (
    <div ref={shellRef} className="portfolio-shell" id="top">
      <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <main>
        <section className="hero" aria-labelledby="hero-title">
          <div className="grid-pattern" aria-hidden="true" />
          <div className="spotlight" aria-hidden="true" />
          <div className="hero-inner">
            <Reveal><p className="hero-kicker">Independent builder · Bengaluru</p></Reveal>
            <Reveal delay={80}>
              <h1 id="hero-title"><span>Preetham</span><span className="accent">Alawandimath.</span></h1>
            </Reveal>
            <Reveal delay={180}>
              <p className="hero-sub"><strong>Developer, automation builder and digital marketer.</strong> I turn ideas, systems and audience into digital work that feels alive.</p>
            </Reveal>
            <Reveal delay={240} className="hero-actions">
              <a className="button-solid" href="#proof" data-testid="button-explore-work">Explore the work <ArrowRight size={15} /></a>
              <a className="button-quiet" href="#story" data-testid="button-enter-story">Enter the story <ArrowUpRight size={15} /></a>
            </Reveal>
            <Reveal delay={300} className="hero-aside">
              <div className="hero-aside-line mono">BMSIT&amp;M · 1st year</div>
              <p>Learning in public, building practical systems, and keeping the useful details visible.</p>
            </Reveal>
          </div>
          <a href="#story" className="scroll-cue" aria-label="Scroll to story" data-testid="link-scroll-story"><i /><span>Scroll</span></a>
        </section>

        <div className="marquee-band" aria-label="Areas of practice">
          <div className="marquee-track">
            {Array.from({ length: 2 }).flatMap((_, copy) => ['BUILD FOR IMPACT', 'WEB DEVELOPMENT', 'AUTOMATION', 'DIGITAL MARKETING', 'SYSTEMS THAT HELP'].map((item) => (
              <span key={`${copy}-${item}`}><span>{item}</span><b> • </b></span>
            )))}
          </div>
        </div>

        <section className="section" id="story" aria-labelledby="story-title">
          <div className="intro-grid">
            <Reveal className="section-heading">
              <SectionLabel index="01">The context</SectionLabel>
              <h2 id="story-title">Built across<br /><em>code, systems &amp; growth.</em></h2>
            </Reveal>
            <Reveal delay={120} className="intro-copy">
              <p>I enjoy turning ideas into practical digital solutions — from websites, Python and SQL projects to Telegram bots, API automation, and digital marketing.</p>
              <p>I’m constantly learning, experimenting, and building things that are useful in the real world.</p>
              <a className="text-link" href="#builds" data-testid="link-build-loop">See the build loop <ArrowDownRight size={14} /></a>
            </Reveal>
          </div>
          <Reveal delay={160} className="skills-wrap">
            <span className="mono">A focused working vocabulary</span>
            <div className="skill-cloud" aria-label="Skills">
              {skills.map((skill) => <span key={skill} data-testid={`skill-${skill.toLowerCase().replaceAll(' ', '-')}`}>{skill}</span>)}
            </div>
          </Reveal>
        </section>

        <section className="section" aria-label="Selected proof metrics">
          <Reveal><div className="metrics">
            <div className="metric"><strong><NumberTicker value={500} suffix="M+" /></strong><small>views across channel snapshots</small></div>
            <div className="metric"><strong><NumberTicker value={30} suffix="M+" /></strong><small>followers across audience work</small></div>
            <div className="metric"><strong><NumberTicker value={80} suffix="M+" /></strong><small>largest channel snapshot</small></div>
            <div className="metric"><strong><NumberTicker value={3} suffix="L+" /></strong><small>revenue snapshot in supplied proof</small></div>
          </div></Reveal>
        </section>

        <div className="parallax-divider" aria-hidden="true">
          <div>BUILD FOR IMPACT&nbsp; • &nbsp;BUILD FOR IMPACT&nbsp; •</div>
        </div>

        <section className="lane-section">
          <div className="section" id="builds" aria-labelledby="build-title">
            <Reveal className="section-heading">
              <SectionLabel index="02">The build loop</SectionLabel>
              <h2 id="build-title">Three lanes.<br /><em>One direction.</em></h2>
            </Reveal>
            <div className="lane-grid">
              {services.map(([number, title, description, icon], index) => (
                <Reveal key={title} delay={index * 80}>
                  <article className="lane-row">
                    <span>{number}</span>
                    <h3>{title}</h3>
                    <p>{description}</p>
                    {icon}
                  </article>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        <section className="section" id="work" aria-labelledby="work-title">
          <div className="proof-header">
            <Reveal className="section-heading">
              <SectionLabel index="03">Selected work</SectionLabel>
              <h2 id="work-title">Recent systems.<br /><em>Visible outcomes.</em></h2>
            </Reveal>
            <Reveal delay={120}><p>Real portfolio material across audience growth, web work, automation, and client proof.</p></Reveal>
          </div>
          <div className="project-grid">
            {projects.map(([image, title, category], index) => (
              <Reveal key={title} delay={index * 70}>
                <a className="project-card" href={index === 1 ? '#analytics' : '#proof'} style={{ backgroundImage: `url("${image}")` }} data-testid={`link-project-${index + 1}`}>
                  <span className="project-shade" />
                  <span className="project-copy">
                    <small>{category}</small>
                    <strong>{title}</strong>
                    <span className="project-link">Open archive <ArrowUpRight size={14} /></span>
                  </span>
                </a>
              </Reveal>
            ))}
          </div>
        </section>

        <div className="parallax-divider muted-divider" aria-hidden="true">
          <div>LEARN IN PUBLIC&nbsp; • &nbsp;MAKE IT USEFUL&nbsp; •</div>
        </div>

        <section className="section" id="proof" aria-labelledby="proof-title">
          <div className="proof-header">
            <Reveal className="section-heading">
              <SectionLabel index="04">Channel archive</SectionLabel>
              <h2 id="proof-title">Audience is not just a number.<br /><em>It is a system.</em></h2>
            </Reveal>
            <Reveal delay={120}><p>Account screenshots supplied for this portfolio, displayed directly and kept in context.</p></Reveal>
          </div>
          <Reveal delay={120}><Gallery items={youtube} tone="youtube" /></Reveal>
          <Reveal delay={180} className="feature-row">
            <article><Play size={18} /><h3>Channel snapshots</h3><p>Account views captured as portfolio material.</p></article>
            <article><Layers3 size={18} /><h3>In-site gallery</h3><p>Use the arrows or dots to move through the archive.</p></article>
            <article><Camera size={18} /><h3>Visual archive</h3><p>A case-study feel instead of a screenshot dump.</p></article>
          </Reveal>
        </section>

        <section className="section" aria-labelledby="payments-title">
          <div className="proof-header">
            <Reveal className="section-heading">
              <SectionLabel index="05">Transaction archive</SectionLabel>
              <h2 id="payments-title">Deals, delivered.<br /><em>Details kept private.</em></h2>
            </Reveal>
            <Reveal delay={120}><p>Four ₹5,000 transaction snapshots supplied for the portfolio. Sensitive payment identifiers are masked for public display.</p></Reveal>
          </div>
          <Reveal delay={120}><Gallery items={payments} tone="payments" /></Reveal>
          <Reveal delay={170}><p className="mono" style={{ margin: '18px auto 0', maxWidth: 850, color: 'var(--faint)', textAlign: 'center' }}><ShieldCheck size={15} style={{ verticalAlign: 'middle', marginRight: 7 }} /> Screenshots are supplied portfolio material; transactions are not independently verified here.</p></Reveal>
        </section>

        <section className="section" id="analytics" aria-labelledby="analytics-title">
          <Reveal className="section-heading">
            <SectionLabel index="06">Social analytics</SectionLabel>
            <h2 id="analytics-title">Reach that leaves<br /><em>a visible trace.</em></h2>
          </Reveal>
          <Reveal delay={100}><p className="intro-copy" style={{ maxWidth: 610, paddingTop: 0, marginTop: 22 }}>Instagram Insights screenshots are presented directly, with headline numbers taken from the supplied screens.</p></Reveal>
          <div className="analytics-grid">
            {analytics.map(([src, label, value, detail], index) => (
              <Reveal key={src} delay={index * 70}>
                <button className="analytics-card" type="button" data-testid={`button-analytics-${index + 1}`} onClick={() => setViewer(src)}>
                  <div className="analytics-media"><img src={src} alt={`${label} analytics`} /><span className="image-hint">Open <ArrowUpRight size={11} /></span></div>
                  <div className="analytics-copy"><span>{label}</span><strong>{value}</strong><small>{detail}</small><em>0{index + 1}</em></div>
                </button>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="section" aria-labelledby="services-title">
          <div className="intro-grid">
            <Reveal className="section-heading">
              <SectionLabel index="07">Automation lab</SectionLabel>
              <h2 id="services-title">What gets<br /><em>unblocked?</em></h2>
            </Reveal>
            <Reveal delay={100} className="intro-copy">
              <p>Think in systems: signal enters, decisions happen, useful output leaves. The details can be documented when the build is public.</p>
            </Reveal>
          </div>
          <div className="lane-grid" style={{ marginTop: 60 }}>
            {[
              ['Trigger', 'A signal worth noticing'],
              ['Logic', 'A thoughtful next step'],
              ['Outcome', 'Time back for people'],
            ].map(([title, description], index) => (
              <Reveal key={title} delay={index * 80}>
                <button className="lane-row" type="button" aria-expanded={openService === index} data-testid={`button-service-${title.toLowerCase()}`} onClick={() => setOpenService(openService === index ? -1 : index)}>
                  <span>0{index + 1}</span>
                  <h3>{title}</h3>
                  <p>{openService === index ? description : 'Open to see the next step.'}</p>
                  <ArrowUpRight size={19} />
                </button>
              </Reveal>
            ))}
          </div>
        </section>

        <section className="community-section" aria-labelledby="community-title">
          <div className="community-inner">
            <Reveal><SectionLabel index="08">Learning in public</SectionLabel></Reveal>
            <Reveal delay={100}><h2 id="community-title">More than a portfolio.<br /><em>A working archive.</em></h2></Reveal>
            <Reveal delay={160}><p>Build notes, experiments, proof, and practical systems belong together. This is where the work stays visible while it grows.</p></Reveal>
            <div className="avatar-row" aria-hidden="true">
              {Array.from({ length: 12 }, (_, index) => <span key={index} style={{ '--avatar': index } as CSSProperties} />)}
            </div>
          </div>
        </section>

        <section className="contact-lamp" id="contact" aria-labelledby="contact-title">
          <div className="contact-inner">
            <Reveal><SectionLabel index="09">Contact</SectionLabel></Reveal>
            <Reveal delay={100}><h2 className="contact-title" id="contact-title">Let’s build<br /><em>something real.</em></h2></Reveal>
            <Reveal delay={180}><p className="contact-copy">For collaborations, projects, digital growth, automation or web development, reach out directly.</p></Reveal>
            <Reveal delay={230} className="contact-links">
              <a className="contact-button" href={`mailto:${email}`} data-testid="link-email"><Mail size={16} /><span>Email</span><small>{email}</small><ArrowUpRight size={14} /></a>
              <a className="contact-button" href="https://wa.me/917406040334" target="_blank" rel="noreferrer" data-testid="link-whatsapp"><span>WhatsApp</span><small>+91 74060 40334</small><ArrowUpRight size={14} /></a>
              <a className="contact-button" href="https://www.instagram.com/preetham_va" target="_blank" rel="noreferrer" data-testid="link-instagram"><span>Instagram</span><small>@preetham_va</small><ArrowUpRight size={14} /></a>
              <a className="contact-button" href="https://www.linkedin.com/in/preetham-alawandimath-b0b014435?utm_source=share_via&utm_content=profile&utm_medium=member_ios" target="_blank" rel="noreferrer" data-testid="link-linkedin"><span>LinkedIn</span><small>preetham-alawandimath</small><ArrowUpRight size={14} /></a>
              <button className="contact-button" type="button" onClick={copyEmail} data-testid="button-copy-email">{copied ? <Check size={16} /> : <Copy size={16} />}<span>{copied ? 'Copied' : 'Copy email'}</span></button>
            </Reveal>
          </div>
        </section>
      </main>

      <footer className="footer">
        <strong>PREETHAM<span>.</span></strong>
        <span>BMSIT&amp;M · Building with intent.</span>
        <div className="footer-nav">
          <a href="#top" className="footer-back" data-testid="link-back-top">Back to top</a>
          <a href={`mailto:${email}`} data-testid="link-footer-email">Email</a>
        </div>
      </footer>

      {viewer && (
        <div className="viewer" role="dialog" aria-modal="true" aria-label="Expanded analytics image" onClick={() => setViewer(null)}>
          <button className="viewer-close" type="button" aria-label="Close image viewer" data-testid="button-close-viewer" onClick={() => setViewer(null)}><X size={19} /></button>
          <img src={viewer} alt="Expanded portfolio analytics screenshot" onClick={(event) => event.stopPropagation()} />
        </div>
      )}
    </div>
  );
}

export default App;