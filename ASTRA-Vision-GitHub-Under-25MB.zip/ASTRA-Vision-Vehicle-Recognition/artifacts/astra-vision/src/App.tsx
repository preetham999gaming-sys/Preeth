import { type ReactNode, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useAnalyzeImage, useGetCatalog, useGetEvaluation, useGetHistory, useGetModelInfo, useHealthCheck } from '@workspace/api-client-react';
import { Activity, AlertTriangle, BarChart3, BookOpen, ChevronRight, CircleHelp, Clock3, Database, FileImage, FolderClock, Gauge, Link as LinkIcon, ListFilter, Microscope, Search, ShieldCheck, UploadCloud } from 'lucide-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const PROJECT_AUTHOR = 'Preetham Alawandimath';

const navItems = [
  { href: '/', label: 'Live analysis', icon: Activity },
  { href: '/evaluation', label: 'Evaluation', icon: BarChart3 },
  { href: '/catalog', label: 'Reference catalog', icon: BookOpen },
  { href: '/history', label: 'Analysis history', icon: FolderClock },
  { href: '/about', label: 'Methodology', icon: CircleHelp },
];

function formatDate(value?: string) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function percent(value?: number | null) {
  return value == null ? '—' : `${(value * 100).toFixed(value < 0.1 ? 1 : 0)}%`;
}

function labelize(value?: string) {
  return value ? value.replace(/[-_]/g, ' ').replace(/\b\w/g, (letter) => letter.toUpperCase()) : '—';
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const health = useHealthCheck();
  const isHealthy = health.data?.status === 'ok' || health.data?.status === 'healthy' || health.data?.status === 'ready';
  return (
    <div className="astra-app">
      <div className="app-shell">
        <aside className="sidebar">
          <div className="brand-mark">
            <div className="brand-symbol"><span /></div>
            <div><div className="brand-name">ASTRA</div><div className="brand-sub">VISION / REVIEW DESK</div></div>
          </div>
          <div className="nav-label">Workspace</div>
          <nav className="nav-stack" aria-label="Primary navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              return <Link key={item.href} href={item.href} className={`nav-link ${location === item.href ? 'active' : ''}`} data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}>
                <Icon /><span>{item.label}</span>{location === item.href && <ChevronRight className="ml-auto" />}
              </Link>;
            })}
          </nav>
          <div className="sidebar-bottom">
            <div className="system-state"><span className={`status-dot ${health.isError ? 'offline' : ''}`} />{health.isLoading ? 'Checking services' : isHealthy ? 'Inference services online' : 'Service status unknown'}</div>
             <div className="sidebar-meta mono">PROJECT BY<br /><strong className="author-credit">{PROJECT_AUTHOR}</strong><br /><br />BUILD 0.1.0<br />ANALYST MODE / READ-ONLY</div>
          </div>
        </aside>
        <div className="main-area">
          <header className="topbar">
            <div><div className="topbar-kicker">Transparent defence-object recognition</div><div className="topbar-title">{location === '/' ? 'Live analysis workspace' : navItems.find((item) => item.href === location)?.label ?? 'ASTRA Vision'}</div></div>
            <div className="topbar-right"><div className="clock mono">{new Date().toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}</div><div className="topbar-pill"><span className="status-dot" />Model ready</div></div>
          </header>
          <main className="main-content">{children}</main>
        </div>
      </div>
    </div>
  );
}

function LoadingPanel({ lines = 3 }: { lines?: number }) {
  return <div className="panel panel-pad" data-testid="status-loading"><div className="skeleton skeleton-block" />{Array.from({ length: lines }).map((_, index) => <div className="skeleton skeleton-line" key={index} />)}</div>;
}

function ErrorPanel({ message, retry }: { message: string; retry?: () => void }) {
  return <div className="error-box" data-testid="status-error"><span><strong>Data unavailable.</strong> {message}</span>{retry && <button className="ghost-button" onClick={retry} data-testid="button-retry">Retry</button>}</div>;
}

function ReadinessPanel() {
  const model = useGetModelInfo();
  const health = useHealthCheck();
  if (model.isLoading) return <LoadingPanel lines={6} />;
  if (model.isError || !model.data) return <ErrorPanel message="The active model manifest could not be read." retry={() => model.refetch()} />;
  const info = model.data;
  const isReady = !health.isError && health.data;
  return <section className="panel panel-pad readiness-panel fade-in delay-1" data-testid="panel-model-readiness">
    <div className="panel-heading"><div><div className="panel-title">Model readiness</div><div className="panel-subtitle">The exact runtime manifest used for each analysis.</div></div><Gauge size={17} /></div>
    <div className="readiness-score"><div className="score-ring">{isReady ? 'OK' : '—'}</div><div><div className="score-label">{isReady ? 'Ready for review' : 'Awaiting service'}</div><div className="score-copy">{isReady ? 'Inference endpoint responding' : 'Health response not confirmed'}</div></div></div>
    <div className="spec-list">
      <div className="spec-row"><span className="spec-label">Model</span><span className="spec-value">{info.name}</span></div>
      <div className="spec-row"><span className="spec-label">Classifier</span><span className="spec-value">{info.classifier}</span></div>
      <div className="spec-row"><span className="spec-label">Task</span><span className="spec-value">{info.task}</span></div>
      <div className="spec-row"><span className="spec-label">Dataset images</span><span className="spec-value mono">{info.dataset_images.toLocaleString()}</span></div>
      <div className="spec-row"><span className="spec-label">Accepted files</span><span className="spec-value">{info.input_formats.join(' / ')}</span></div>
      <div className="spec-row"><span className="spec-label">Max file size</span><span className="spec-value mono">{info.max_file_size_mb} MB</span></div>
    </div>
    <div className="eyebrow" style={{ marginTop: 18 }}>Supported classes</div>
    <div className="class-chips">{info.supported_classes.map((item) => <span className="class-chip" key={item}>{labelize(item)}</span>)}</div>
  </section>;
}

function UploadPanel({ onResult }: { onResult: (result: any, file: File) => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const analyze = useAnalyzeImage();
  const chooseFile = (nextFile?: File) => {
    if (!nextFile) return;
    setFile(nextFile);
    setPreview(URL.createObjectURL(nextFile));
  };
  const submit = () => {
    if (file) analyze.mutate({ data: { image: file } }, { onSuccess: (result) => onResult(result, file) });
  };
  return <section className="panel panel-pad upload-panel fade-in" data-testid="panel-upload">
    <div className="panel-heading"><div><div className="panel-title">New image analysis</div><div className="panel-subtitle">Upload one image. ASTRA returns only supported-class predictions.</div></div><FileImage size={17} /></div>
    <div className={`drop-zone ${preview ? 'has-image' : ''} ${dragging ? 'dragging' : ''}`} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); chooseFile(event.dataTransfer.files[0]); }} onClick={() => !preview && inputRef.current?.click()} data-testid="dropzone-image">
      <input ref={inputRef} type="file" accept="image/*" onChange={(event) => chooseFile(event.target.files?.[0])} data-testid="input-image-upload" />
      {preview ? <div className="preview-frame"><img src={preview} alt="Selected analysis preview" className="preview-image" data-testid="img-analysis-preview" />{analyze.isPending && <div className="scan-line" />}</div> : <div className="upload-inner"><div className="upload-glyph"><UploadCloud size={23} /></div><div className="upload-title">Drop an image to inspect</div><div className="upload-help">PNG, JPEG, or WEBP. Use a clear frame where the object is visible. The source is sent to the active inference service.</div><button className="ghost-button" onClick={(event) => { event.stopPropagation(); inputRef.current?.click(); }} data-testid="button-browse-image">Browse files</button></div>}
    </div>
    <div className="upload-footer"><div className="file-note mono">{file ? `${file.name} · ${(file.size / 1024 / 1024).toFixed(2)} MB` : 'No image selected'}</div>{preview && <div style={{ display: 'flex', gap: 8 }}><button className="ghost-button" onClick={() => { setFile(null); setPreview(''); }} data-testid="button-clear-image">Clear</button><button className="action-button accent" onClick={submit} disabled={analyze.isPending} data-testid="button-analyze-image">{analyze.isPending ? 'Running inference…' : 'Analyze image'}<ChevronRight size={14} /></button></div>}</div>
    {analyze.isError && <div style={{ marginTop: 13 }}><ErrorPanel message="The image could not be analyzed. Check the file and try again." retry={() => submit()} /></div>}
  </section>;
}

function AnalysisResult({ result, file }: { result: any; file: File }) {
  const predictions = result.top_predictions ?? [];
  return <section className="panel panel-pad result-panel fade-in" data-testid="panel-analysis-result">
    <div className="panel-heading"><div><div className="eyebrow">Analysis response · {formatDate(result.analyzed_at)}</div><div className="panel-title" style={{ marginTop: 7 }}>Evidence summary</div></div><span className="confidence-badge">{labelize(result.confidence_status)} confidence</span></div>
    <div className="result-grid">
      <div><div className="result-label">Primary supported class</div><div className="result-lead" data-testid="text-prediction">{labelize(result.prediction?.label)}</div><div className="confidence-bar"><div className="confidence-fill" style={{ width: `${Math.max(2, (result.prediction?.confidence ?? 0) * 100)}%` }} /></div><div className="confidence-meta"><span>Model confidence</span><strong className="mono">{percent(result.prediction?.confidence)}</strong></div>
        <div className="evidence-box">{result.reference_match ? <><div className="evidence-tag">Reference model match · {labelize(result.reference_match.evidence_level)}</div><div className="evidence-name">{result.reference_match.exact_name}</div><div className="evidence-copy">{result.reference_match.reference_title} · similarity {percent(result.reference_match.similarity)}</div><a href={result.reference_match.source_url} target="_blank" rel="noreferrer" className="repo-link" data-testid="link-reference-source">Open source record <LinkIcon size={11} /></a></> : <><div className="evidence-tag">Reference model match</div><div className="evidence-name">No evidence match available</div><div className="evidence-copy">The classifier returned a supported class, but no catalog reference was linked to this image.</div></>}</div>
      </div>
      <div><div className="result-label">Top alternatives</div><div className="prediction-list" style={{ marginTop: 14 }}>{predictions.map((prediction: any) => <div className="prediction-row" key={`${prediction.rank}-${prediction.label}`}><div className="rank">0{prediction.rank}</div><div><div>{labelize(prediction.label)}</div><div className="prediction-track"><div className="prediction-fill" style={{ width: `${prediction.confidence * 100}%` }} /></div></div><div className="prediction-percent">{percent(prediction.confidence)}</div></div>)}</div><div className="result-explanation">{result.explanation}</div>{result.detections?.length > 0 && <div style={{ marginTop: 19 }}><div className="result-label">Detected regions</div><div className="table-wrap"><table className="data-table"><thead><tr><th>Class</th><th>Confidence</th><th>Box</th></tr></thead><tbody>{result.detections.map((detection: any, index: number) => <tr key={`${detection.class_name}-${index}`}><td className="table-primary">{labelize(detection.class_name)}</td><td className="mono">{percent(detection.confidence)}</td><td className="table-secondary mono">{detection.box ? `${Math.round(detection.box.width * 100)}% × ${Math.round(detection.box.height * 100)}%` : 'No box returned'}</td></tr>)}</tbody></table></div></div>}<div className="spec-list"><div className="spec-row"><span className="spec-label">Inference time</span><span className="spec-value mono">{result.inference_time_ms} ms</span></div><div className="spec-row"><span className="spec-label">Preprocessing</span><span className="spec-value">{result.preprocessing?.applied ? result.preprocessing.summary : 'None applied'}</span></div><div className="spec-row"><span className="spec-label">Runtime</span><span className="spec-value">{result.model?.classifier} · {result.model?.device}</span></div><div className="spec-row"><span className="spec-label">Input</span><span className="spec-value">{file.name} · {result.image?.width} × {result.image?.height}</span></div></div></div>
    </div>
  </section>;
}

function Home() {
  const [result, setResult] = useState<any>(null);
  const [file, setFile] = useState<File | null>(null);
  const history = useGetHistory();
  return <><div className="page-head fade-in"><div><div className="eyebrow">Operator console / 01</div><h1 className="page-title">See the object.<br /><span style={{ color: 'hsl(var(--muted-foreground))' }}>Show the evidence.</span></h1><p className="page-copy">A transparent first pass for reviewers working with defence imagery. Every output carries the model, dataset scope, and confidence context with it.</p></div><Link href="/about" className="ghost-button" data-testid="link-about-methodology">How ASTRA reasons <ChevronRight size={13} /></Link></div>
    <div className="home-grid"><UploadPanel onResult={(nextResult, nextFile) => { setResult(nextResult); setFile(nextFile); }} /><ReadinessPanel /></div>
    {result && file && <AnalysisResult result={result} file={file} />}
    {!result && <div className="section-grid" style={{ marginTop: 18 }}><div className="panel panel-pad"><div className="panel-heading"><div><div className="panel-title">Recent server analyses</div><div className="panel-subtitle">A short trail of the latest review activity.</div></div><Link href="/history" className="ghost-button" data-testid="link-view-history">View all <ChevronRight size={13} /></Link></div>{history.isLoading ? <LoadingPanel lines={2} /> : history.isError ? <ErrorPanel message="History is currently unavailable." retry={() => history.refetch()} /> : history.data?.items?.length ? <div className="history-list">{history.data.items.slice(0, 3).map((item) => <div className="panel history-row" key={item.id} data-testid={`row-recent-analysis-${item.id}`}><span className="history-marker" /><div><div className="history-file">{item.file_name}</div><div className="history-date">{formatDate(item.analyzed_at)}</div></div><div className="history-category">{labelize(item.category)}</div><div className="history-evidence">{item.evidence}</div><span className="confidence-badge">{percent(item.confidence)}</span></div>)}</div> : <div className="empty-state"><Clock3 size={22} /><p>No analyses recorded yet. Your first upload will appear here.</p></div>}</div></div>}
  </>;
}

function EvaluationPage() {
  const evaluation = useGetEvaluation();
  if (evaluation.isLoading) return <><PageIntro eyebrow="Evaluation / 02" title="Know what the model knows." copy="Dataset composition and evaluation results are shown as returned by the active service. No metric is inferred or rounded into existence." /><LoadingPanel lines={7} /></>;
  if (evaluation.isError || !evaluation.data) return <><PageIntro eyebrow="Evaluation / 02" title="Know what the model knows." copy="Dataset composition and evaluation results are shown as returned by the active service." /><ErrorPanel message="Evaluation data could not be loaded." retry={() => evaluation.refetch()} /></>;
  const data = evaluation.data; const report = data.dataset_report; const metrics = data.metrics;
  return <><PageIntro eyebrow="Evaluation / 02" title="Know what the model knows." copy="Dataset composition and evaluation results are shown as returned by the active service. No metric is inferred or rounded into existence." /><div className="stats-row"><Stat label="Evaluated" value={data.evaluated ? 'Yes' : 'No'} foot="Evaluation status" /><Stat label="Images" value={report.total_images.toLocaleString()} foot={`${report.classes} supported classes`} /><Stat label="Test split" value={report.test_images.toLocaleString()} foot={report.split} /><Stat label="Invalid / dupes" value={`${report.invalid_images} / ${report.duplicate_images}`} foot="Excluded from report" /></div><div className="metric-grid"><section className="panel panel-pad"><div className="panel-heading"><div><div className="panel-title">Reported metrics</div><div className="panel-subtitle">Null means the service did not report a value.</div></div><BarChart3 size={17} /></div><div className="metric-cells">{[['Accuracy', metrics.accuracy], ['Top 3', metrics.top3_accuracy], ['Precision', metrics.precision], ['Recall', metrics.recall], ['F1', metrics.f1]].map(([name, value]) => <div className="metric-cell" key={String(name)}><div className="metric-name">{name}</div><div className="metric-value mono">{percent(value as number | null)}</div></div>)}</div><div className="note-box" style={{ marginTop: 17 }}>{data.note}</div></section><section className="panel panel-pad"><div className="panel-heading"><div><div className="panel-title">Dataset split</div><div className="panel-subtitle">{report.source}</div></div><Database size={17} /></div><div className="distribution">{[['Train', report.train_images], ['Validation', report.validation_images], ['Test', report.test_images]].map(([name, count]) => <div className="distribution-row" key={String(name)}><span>{name}</span><div className="distribution-track"><div className="distribution-fill" style={{ width: `${(Number(count) / report.total_images) * 100}%` }} /></div><span className="mono">{Number(count).toLocaleString()}</span></div>)}</div><div className="eyebrow" style={{ marginTop: 23, marginBottom: 12 }}>Class distribution</div><div className="distribution">{Object.entries(report.class_distribution).map(([name, count]) => <div className="distribution-row" key={name}><span>{labelize(name)}</span><div className="distribution-track"><div className="distribution-fill" style={{ width: `${(count / Math.max(...Object.values(report.class_distribution))) * 100}%`, background: 'hsl(var(--chart-3))' }} /></div><span className="mono">{count}</span></div>)}</div></section></div><section className="panel panel-pad" style={{ marginTop: 18 }}><div className="panel-heading"><div><div className="panel-title">Per-class performance</div><div className="panel-subtitle">Class-level accuracy where reported by the evaluation endpoint.</div></div><ListFilter size={17} /></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Class</th><th>Evaluation images</th><th>Accuracy</th><th>Readout</th></tr></thead><tbody>{data.per_class.map((item) => <tr key={item.label}><td className="table-primary">{labelize(item.label)}</td><td className="mono">{item.image_count.toLocaleString()}</td><td className="mono">{percent(item.accuracy)}</td><td className="table-secondary">{item.accuracy == null ? 'Not reported' : item.accuracy > .8 ? 'Strongest reported signal' : 'Review with context'}</td></tr>)}</tbody></table></div></section></>;
}

function PageIntro({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy: string; action?: ReactNode }) {
  return <div className="page-head fade-in"><div><div className="eyebrow">{eyebrow}</div><h1 className="page-title">{title}</h1><p className="page-copy">{copy}</p></div>{action}</div>;
}
function Stat({ label, value, foot }: { label: string; value: string; foot: string }) { return <div className="panel stat-card fade-in"><div className="stat-kicker">{label}</div><div className="stat-number mono" data-testid={`text-stat-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</div><div className="stat-foot">{foot}</div></div>; }

function CatalogPage() {
  const catalog = useGetCatalog(); const [query, setQuery] = useState('');
  const entries = useMemo(() => catalog.data?.entries?.filter((entry) => `${entry.exact_name} ${entry.category} ${entry.source_title} ${entry.artist}`.toLowerCase().includes(query.toLowerCase())) ?? [], [catalog.data?.entries, query]);
  if (catalog.isLoading) return <><PageIntro eyebrow="Reference catalog / 03" title="Trace the visual reference." copy="Exact source names, model names, and licenses for the reference set used alongside predictions." /><LoadingPanel lines={6} /></>;
  if (catalog.isError || !catalog.data) return <><PageIntro eyebrow="Reference catalog / 03" title="Trace the visual reference." copy="Exact source names, model names, and licenses for the reference set used alongside predictions." /><ErrorPanel message="Catalog data could not be loaded." retry={() => catalog.refetch()} /></>;
  return <><PageIntro eyebrow="Reference catalog / 03" title="Trace the visual reference." copy={`${catalog.data.entries.length} reference records. Search by exact model name, class, source title, or artist.`} /><div className="search-row"><div className="search-wrap"><Search size={15} /><input className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search exact name, class, or source…" data-testid="input-catalog-search" /></div><div className="topbar-pill">{entries.length} records</div></div>{entries.length ? <div className="catalog-grid">{entries.map((entry) => <article className="panel catalog-card" key={entry.id} data-testid={`card-catalog-${entry.id}`}><div className="catalog-image">{entry.image_url ? <img src={entry.image_url} alt={entry.exact_name} loading="lazy" /> : <div className="catalog-image-fallback">{labelize(entry.category)}</div>}</div><div className="catalog-body"><div className="catalog-name">{entry.exact_name}</div><div className="catalog-meta">{labelize(entry.category)} · {entry.file_name}</div><div className="catalog-foot"><span>{entry.source_title}{entry.artist ? ` · ${entry.artist}` : ''}</span><span className="license">{entry.license}</span></div><a className="repo-link" href={entry.source_url} target="_blank" rel="noreferrer" data-testid={`link-catalog-source-${entry.id}`}>View source record <LinkIcon size={11} /></a></div></article>)}</div> : <div className="panel empty-state"><Search size={23} /><p>No reference records match “{query}”.</p></div>}</>;
}

function HistoryPage() {
  const history = useGetHistory();
  return <><PageIntro eyebrow="Analysis history / 04" title="A quiet audit trail." copy="Recent server-side predictions, retained as a compact review log. History records do not replace the evidence returned with each analysis." action={<button className="ghost-button" onClick={() => history.refetch()} data-testid="button-refresh-history">Refresh history</button>} />{history.isLoading ? <LoadingPanel lines={7} /> : history.isError ? <ErrorPanel message="History data could not be loaded." retry={() => history.refetch()} /> : history.data?.items?.length ? <section className="history-list">{history.data.items.map((item) => <div className="panel history-row" key={item.id} data-testid={`row-history-${item.id}`}><span className="history-marker" /><div><div className="history-file">{item.file_name}</div><div className="history-date">{formatDate(item.analyzed_at)}</div></div><div className="history-category">{labelize(item.category)}</div><div className="history-evidence">{item.evidence}</div><span className="confidence-badge">{percent(item.confidence)}</span></div>)}</section> : <div className="panel empty-state"><FolderClock size={24} /><p>No analyses have been recorded yet.</p><Link href="/" className="action-button accent" data-testid="link-start-first-analysis">Start first analysis <ChevronRight size={14} /></Link></div>}</>;
}

function AboutPage() {
  const model = useGetModelInfo(); const evaluation = useGetEvaluation();
  return <><PageIntro eyebrow="Methodology / 05" title="Trust is a feature." copy="ASTRA Vision is built for the moment after a model speaks: the reviewer still needs to know what was measured, what was matched, and where uncertainty starts." /><div className="about-grid"><section className="panel panel-pad"><div className="panel-heading"><div><div className="panel-title">How a result is assembled</div><div className="panel-subtitle">A readable chain from image to review context.</div></div><Microscope size={17} /></div><div className="number-list"><div className="number-item"><div className="number">01</div><div className="number-copy"><strong>Inspect the input</strong>File dimensions, format, and preprocessing are returned so the reviewer can see what entered the pipeline.</div></div><div className="number-item"><div className="number">02</div><div className="number-copy"><strong>Classify within scope</strong>The active classifier selects from its supported classes. An unsupported confidence state is not converted into a confident label.</div></div><div className="number-item"><div className="number">03</div><div className="number-copy"><strong>Show alternatives</strong>Top predictions remain visible instead of hiding close calls behind one headline.</div></div><div className="number-item"><div className="number">04</div><div className="number-copy"><strong>Attach evidence when available</strong>Reference matches expose exact names, evidence level, source records, and licensing—not an invented citation.</div></div></div></section><section className="repo-box"><div className="repo-title">ACTIVE REFERENCE REPOSITORY</div><div className="repo-name">{model.data?.reference_repository ?? 'Loading repository manifest'}</div><div className="repo-copy">The catalog is a reference layer, not ground truth. A visual neighbor can support review without proving identity.</div>{model.data && <><div className="repo-title" style={{ marginTop: 25 }}>MODEL LIMITATIONS</div><ul className="repo-copy" style={{ paddingLeft: 17 }}>{model.data.limitations.map((limitation) => <li key={limitation} style={{ marginTop: 6 }}>{limitation}</li>)}</ul></>}<a href={model.data?.reference_repository} target="_blank" rel="noreferrer" className="repo-link" data-testid="link-reference-repository">{model.data?.reference_repository ?? 'Repository unavailable'} <LinkIcon size={11} /></a></section></div><div className="section-grid" style={{ marginTop: 18 }}><section className="panel panel-pad"><div className="panel-heading"><div><div className="panel-title">Known limitations</div><div className="panel-subtitle">Read before using outputs in a consequential review.</div></div><AlertTriangle size={17} /></div><div className="prose-block"><p><strong>Recognition is bounded.</strong> ASTRA only knows the supported class vocabulary exposed in the active model manifest. It cannot establish intent, ownership, operational status, or identity from an image.</p><p><strong>Reference is not confirmation.</strong> Catalog and visual-neighbor matches are evidence-backed pointers for a human reviewer. They are not independent verification.</p><p><strong>Evaluation is dataset-specific.</strong> Reported metrics describe the evaluation data and split returned by the service. They should not be read as a universal field accuracy claim.</p></div></section><section className="panel panel-pad"><div className="panel-heading"><div><div className="panel-title">Live manifest snapshot</div><div className="panel-subtitle">Values are sourced directly from the API.</div></div><ShieldCheck size={17} /></div><div className="spec-list">{model.data && <><div className="spec-row"><span className="spec-label">Active model</span><span className="spec-value">{model.data.name}</span></div><div className="spec-row"><span className="spec-label">Catalog models</span><span className="spec-value mono">{model.data.catalog_models}</span></div><div className="spec-row"><span className="spec-label">Evaluation state</span><span className="spec-value">{evaluation.data ? evaluation.data.evaluated ? 'Evaluated' : 'Not evaluated' : 'Loading'}</span></div></>}</div></section></div></>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Shell><Switch><Route path="/" component={Home} /><Route path="/evaluation" component={EvaluationPage} /><Route path="/catalog" component={CatalogPage} /><Route path="/history" component={HistoryPage} /><Route path="/about" component={AboutPage} /><Route component={NotFound} /></Switch></Shell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;