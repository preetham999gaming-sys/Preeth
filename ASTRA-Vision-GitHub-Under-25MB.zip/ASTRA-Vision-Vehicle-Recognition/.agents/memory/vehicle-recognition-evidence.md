---
name: Vehicle recognition evidence policy
description: Trust boundaries for exact vehicle names and evaluation claims in ASTRA Vision.
---

Exact vehicle names are evidence-backed catalog outputs only: an identical uploaded reference can be named exactly, while a visual-neighbor name must remain visibly labeled as a reference and not as identity confirmation. Images in the starter set have image-level categories but no bounding-box annotations, so localization and detection metrics must not be claimed.

**Why:** The supplied dataset contains 150 mixed-quality images across five categories and credits, but it does not provide the annotations required for fine-grained identity or object detection claims.

**How to apply:** Keep class prediction, catalog evidence, and evaluation state as separate concepts in both the API and UI. Show `Not evaluated` until a held-out trained checkpoint has produced real metrics.